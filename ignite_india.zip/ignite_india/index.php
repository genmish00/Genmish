<!-- ===========================INDEX PAGE======================================== -->
<!-- Include head -->
<?php include 'include/head.php';?>

<!-- ----------------body section start here----------------- -->
<body>
    <!-- include header  -->
    <?php include 'include/header.php';?>

    <!-- Carousel section -->
        <!--end Carousel section -->
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ignite_india_carousel.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-target="#carouselExampleFade" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleFade" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>

        <!-- about section -->
        <div class="about_us py-5" id="about_us">
            <div class="container-fluid about_content">
                <h5>About Us</h5>
                <div class="row justify-content-center align-items-center">
                    <div class="col-md-7 ">
                        <h3>IGNITE INDIA EDUCATION</h3>
                        <p>Ignite India Education is inspired by the former President of India Bharat Ratna Dr. APJ Abdul Kalam’s vision of “India Beyond 2020” <b>Biography of A.P.J.Abdul Kalam.</b> Our aim is to fulfill his vision by empowering society and transforming India into a developed nation through education. We are committed to spreading awareness among the new generation and providing preparation classes for different entrance exams for new-age career opportunities. Ignite India was established in 2006. Ignite Study Points are in across the country including New Delhi, Bangalore, Mumbai, Chennai, Hyderabad, Ahmedabad, Patna, etc. The objective of this initiative is to guide, mentor, and inspire young minds who want to pursue careers in the fields of Architecture, Design, Fashion, Fine Arts, Interior, Law, Hotel, Management, and other new-age career opportunities. This initiative is managed by design, management, and technology professionals and committed to transforming India into a developed nation. We also Organise Annual IGNITE Awards, Ignite Career Fest, Ignite India Meraki, and other events throughout the year to spread awareness  among students</p>
                    </div>
                    <div class="col-md-5 mt-5 about_video">
                    <iframe width="100%" height="315" src="https://www.youtube.com/embed/L5NOBs3_L_E?si=vZ5UlQ5eEcTMudB8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>                       
                    </div>
                </div>
            </div>
        </div>
        <!-- end about section -->

        <!-- our success-->
        <div class="success_stores py-5" style="background-color:#f1f1f1;">
            <div class="container-fluid">
                <h3 class="text-center mb-3"> Success Stories</h3>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                    <div id="stores-slider" class="owl-carousel">
                <div class="testimonial">
                   <img src="images/results.jpg" alt="">
                </div>
                <div class="testimonial">
                    <img src="images/result-1.jpg" alt="">
                </div>
                <div class="testimonial">
                    <img src="images/result-2.jpg" alt="">
                </div>
                <div class="testimonial">
                   <img src="images/result-3.jpg" alt="">
                </div>
 
                <div class="testimonial">
                  <img src="images/result-4.jpg" alt="">
                </div>
                <div class="testimonial">
                  <img src="images/result-5.jpg" alt="">
                </div>
                <div class="testimonial">
                  <img src="images/result-6.jpg" alt="">
                </div>
            </div>
                    </div>
                    </div>
                </div>
                <div class="test-button text-center mt-5">
                <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Veiw All</button></a>
                </div>
            </div>
        </div>
         <!--END our success -->

        <!-- our courses section -->
        <div class="our_courses py-5" id="our_courses">
            <div class="container-fluid">
                <center>
                    <h2>Our Courses</h2>
                    <hr>
                </center>
                <div class="row">
                    <div class="col-md-12">
                        <div id="carousel" class="owl-carousel" >
                            <div class="testimonial">
                                <div class="card">
                                    <h3>NIFT</h3>
                                    <P>The National Institute of Fashion Technology (NIFT) is a premier institution in India renowned for fostering creativity and excellence in the field of fashion and design.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>NID</h3>
                                    <P>The National Institute of Design (NID) is a leading design school in India, recognized internationally for its innovation and contribution to the design <br> industry.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>UID</h3>
                                    <P>The Unitedworld Institute of Design (UID) is a distinguished design school in India, known for its holistic approach to design education and fostering innovation in students.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>PEARL</h3>
                                    <P>PEARL Academy is a renowned institution in India, specializing in design, fashion, business, and media education, preparing students for creative and professional excellence.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>LPU</h3>
                                    <P>Lovely Professional University (LPU) is one of India's largest and most prestigious private universities, offering a wide range of academic programs across various disciplines.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>   <div class="testimonial">
                                <div class="card">
                                    <h3>NATA</h3>
                                    <P>The National Aptitude Test in Architecture (NATA) is a national-level examination in India that assesses the aptitude of candidates for admission to undergraduate architecture programs.</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>UCEED</h3>
                                    <P>UCEED (Undergraduate Common Entrance Examination for Design) is a national-level entrance exam conducted for admission to undergraduate design programs at the Indian Institute of</P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>CEED</h3>
                                    <P>CEED (Common Entrance Examination for Design) is a national-level exam conducted for admission to postgraduate design programs in prestigious institutions across India, </P>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>CLAT</h3>
                                    <p>CLAT (Common Law Admission Test) is a national-level entrance exam in India for admission to undergraduate and postgraduate law programs offered by various law </p>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>BBA</h3>
                                    <p>Bachelor of Business Administration (BBA) is an undergraduate academic degree program that provides students with a foundational understanding of business principles and </p>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>Fine Arts</h3>
                                    <p>Fine Arts is a diverse field encompassing various forms of visual and performing arts, including painting, sculpture, drawing, printmaking, photography, and more, allowing </p>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="card">
                                    <h3>Professional courses</h3>
                                    <p>Professional courses are specialized programs designed to provide practical skills and knowledge in specific industries or fields, aimed at preparing individuals for successful </p>
                                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- end courses section -->

        <!-- FACILITATORS section -->
        <div class="facilitators py-5">
            <div class="container-fluid">
                <h3 class="text-center mb-5">Our Team</h3>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                    <div id="testimonial-slider" class="owl-carousel">
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/gupta.webp">
                    </div>
                    <p class="description">
                    Ignite India Education is inspired...
                    </p>
                    <h3 class="title">Akash Gupta</h3>
                    <span class="post">12 Years experience</span>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/govind.webp">
                    </div>
                    <p class="description">
                    Fashion Designer, Educational and Career Counselor. He is an alumnus of NIFT and won the Best Graduation Project Award. He is guiding students from the past 15 years.
                    </p>
                    <h3 class="title">govind Kumar singh</h3>
                    <span class="post">12 Years experience</span>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/am.webp">
                    </div>
                    <p class="description">
                    Fashion & Textile Designer, Educational and Career Counselor. He is an alumnus of NIFT and won the Best Graduation Project Award. He is guiding students from the past 10 years.                    </p>
                    <h3 class="title">Gourav Roy</h3>
                    <span class="post">12 Years experience</span>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/akhilesh.webp">
                    </div>
                    <p class="description">
                    Ignite India Education is inspired by the former President of India Bharat Ratna Dr. APJ Abdul Kalam’s vision of “India Beyond 2020”. Our aim is to fulfil his vision by empowering society and transforming India into a developed nation through education.                    </p>
                    <h3 class="title">Akhilesh Kumar</h3>
                    <span class="post">12 Years experience</span>
                </div>
 
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/krishna.webp">
                    </div>
                    <p class="description">
                    Fashion & Textile Designer, Educational and Career Counselor. He is an alumnus of NIFT and won the Best Graduation Project Award. He is guiding students from the past 10 years.                    </p>
                    <h3 class="title">Krishna Nand Singh</h3>
                    <span class="post">12 Years experience</span>
                </div>
            </div>
                    </div>
                </div>
                <div class="test-button text-center mt-5">
                <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Meet all Theme</button></a>
                </div>
            </div>
        </div>
        <!-- end FACILITATORS section -->
        <!-- testimonial section -->
        <div class="facilitators py-5" style="background-color:#f1f1f1;">
            <div class="container-fluid">
                <h3 class="text-center mb-5">Our Testimonial</h3>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                    <div id="testimoniall-slider" class="owl-carousel">
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/user.png">
                    </div>
                    <p class="description">
                    Best design institutions in Bangalore ,with well qualified faculties. Anyone can develop design skills in this institution as it provides training from basic to advance level..
                    </p>
                    <h3 class="title">Mithun TJ</h3>
                   
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/user.png">
                    </div>
                    <p class="description">
                    This is a perfect institute for any designing aspirant. The teachers and management all are very good and helpful. And also they are really very supportive.
                    </p>
                    <h3 class="title">Khushi Goyal</h3>
                   
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/user.png">
                    </div>
                    <p class="description">
                    Amazing experience. Ignite India has helped us explore stuff and guide you for your future. The faculty support is very good and satisfying.</p>
                    <h3 class="title">Isha Pathak</h3>
                   
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/user.png">
                    </div>
                    <p class="description">
                    IIgnite india is the best platform to prepare for all kind of design colleges.The faculties here are great they help you to discover your skills and guide you through different aspects of design.  </p>
                    <h3 class="title">Sanjana Duraisamy</h3>
                    
                </div>
 
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/user.png">
                    </div>
                    <p class="description">
                    It is one of the best coaching institute in the Banglore. The faculty members are very friendly and helpful. I got a very new perspective towards the entrance as to how each question has to be dealt with. </p>
                    <h3 class="title">Abhirami C L</h3>
                  
                </div>
            </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- end testimonial -->

        <!-- coaching section start -->
        <div class="coaching py-5" id="coaching">
            <div class="container-fluid">
                <h3 class="text-center mb-5">Coaching</h3>
                <div class="row">
                    <div class="col-md-6">
                        <img src="images/exam.jpg" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-6">
                        <h4>IGNITE INDIA</h4>
                        <strong>NIFT | NID | NATA | UCEED | CEED |</strong>
                    <ul>
                        <li><i class="fa-solid fa-circle-check"></i> NIFT Entrance Exam coaching</li>
                        <li><i class="fa-solid fa-circle-check"></i> NID Entrance Exam coaching</li>
                        <li><i class="fa-solid fa-circle-check"></i> NATA Entrance Exam coaching</li>
                        <li> <i class="fa-solid fa-circle-check"></i> UCEED Entrance Exam coaching</li>
                        <li><i class="fa-solid fa-circle-check"></i> CEED Entrance Exam coaching</li>
                    </ul>
                    <a href="#exampleModal"  data-toggle="modal"  data-toggle="tooltip"><button>Read more</button></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- end coaching section -->



        <!-- abroad section -->
        <div class="abroad py-5" style="background-color:#f1f1f1;">
            <div class="container-fluid" id="abroad" >
                <h3 class="text-center">STUDY ABROAD</h3>
                <h6 class="text-center mb-5">UNIVERSITY OF READING</h6>
                <div class="row">
                    <div class="col-md-3">
                        <img src="images/abroad.webp" class="img-fluid" alt="">

                    </div>
                    <div class="col-md-9">
                        <p>Ignite India Education is inspired by the former President of India Bharat Ratna Dr. APJ Abdul Kalam’s vision of “India Beyond 2020”. Our aim is to fulfil his vision by empowering society and transforming India into a developed nation through education. </p>
                        <p>We are committed to spread awareness among new generation, and provides preparation classes for different  entrance exams for new age career opportunities. Ignite India was established in 2006. Ignite Study Points are in across country  including New Delhi , Bangalore, Mumbai, Chennai, Hyderabad, Ahmedabad, Patna etc </p>
                    </div>
                </div>
                <p>Objective of this initiative is to guide, mentor and inspire young minds who want to pursue career in the fields of Architecture, Design, Fashion, Fine Arts, Interior, Law, Hotel, Management and other new age career opportunities. </p>
                <p>This initiative is managed by design, management and technology professionals and committed to transform India in to the developed nation. We also Organise Annual IGNITE Awards, Ignite Career Fest, Ignite India Miraki and other events throughout the year to spread awareness  among students</p>
            </div>
        </div>
        <!-- end abroad section -->

        <!-- our media coverage -->
        <div class="media_coverage py-5">
            <div class="container">
                <h3 class="text-center mb-5">Our Media Coverage</h3>
                <hr>
                <div class="row">
                    <div class="col-md-2 col-6">
                    <img src="images/daily.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-2 col-6">
                    <img src="images/google.PNG" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-2 col-6">
                    <img src="images/jio_news.jpg" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-2 col-6">
                    <img src="images/theprint.PNG" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-2 col-6">
                    <img src="images/latest.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-2 col-6">
                    <img src="images/lokmat.png" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </div>

        <!-- contact us section -->
        <!-- mail send for enquiry -->
<?php 
error_reporting(0);

extract($_POST);
if (isset($send)) 
 {
			//  send to ADMIN Confirmation
			$to='mohan.genmishindia@gmail.com';
			$subject='For exampleModal';
			$message='
			<html>
			<head><title>New Enquiry Details</title></head>
			<body>
			<table border=1 style="border-collapse:collapse; width:100%;">
			       
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Name</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$name.'</th></tr>
				
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Email</th><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">'.$email.'</th></tr>
			        
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Phone</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$phone.'</th></tr>
              <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Message</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$message.'</th></tr>
              
			        
			         
			</table>
			</body>
			</html>
			';

			$headers='MME-Version:  1.0'."\r\n";
			$headers='Content-Type: text/html; charset=iso-8859-1'."\r\n";
			$headers .= 'From: Ignite India . <mohan.genmishindia@gmail.com>' . "\r\n";

			mail($to, $subject, $message, $headers);
			echo"<script>alert('Message Sent Successfully')</script>";
			echo"<script>window.location.href='index.php'</script>";
}
 ?>
        <div class="contact_us py-5" id="contact_us">
            <div class="container-fluid">
                <h3 class="text-center mb-5">Contact Us</h3>
                <hr>
                <div class="row">
                    <div class="col-md-4 contact_form">
                        <h5>Fill Your Details</h5>
                        <form id="myForm" action="" method="POST" class="p-3">
    <div class="form-group">
        <input type="text" name="name" class="form-control" placeholder="Enter Your Name" required>
    </div>
    <div class="form-group">
        <input type="email" name="email" class="form-control" placeholder="Enter Your Email" required>
    </div>
    <div class="form-group">
        <input type="text" name="phone" id="phone" class="form-control" placeholder="Enter Your Number" required>
        <small id="phoneError" style="color: red;"></small>
    </div>
    <div class="form-group">
        <textarea name="message" class="form-control" placeholder="Enter Your Message" required></textarea>
    </div>
    <div class="form-group">
        <button name="submit" type="submit">Submit</button>
    </div>
</form>
<script>
    document.getElementById("myForm").addEventListener("submit", function(event) {
        var phoneInput = document.getElementById("phone");
        var phone = phoneInput.value.trim();

        // Regular expression for 10-digit Indian mobile numbers
        var phoneRegex = /^[6-9]\d{9}$/;

        if (!phoneRegex.test(phone)) {
            var phoneError = document.getElementById("phoneError");
            phoneError.textContent = "Please enter a valid 10-digit Indian mobile number.";
            event.preventDefault(); // Prevent form submission
        }
    });
</script>
                    </div>
                    <div class="col-md-8 contact_location">
                        <h5>Our Location</h5>
                        <div id="location-slider" class="owl-carousel">
                <div class="testimoniall">
                  <div class="card p-3">
                    <h5>Banglore</h5>
                    <small>Ignite India Education
Best NIFT NID NATA UCEED CEED Coaching in HSR Layout Bangalore
#1658, First Floor, 27th Main Rd,
Near NIFT College, Sector 2,
HSR Layout, Bengaluru,
Karnataka 560102
+91-9972046911
live@iginteindiaedu.com
Contact – Mr. K. Nand</small>
                  </div>
                </div>
                <div class="testimoniall">
                    <div class="card p-3">
                        <h5>Karnataka</h5>
                        <small>HSR LAYOUT [Bangalore Head Office]</small>
                        <small><b>Address:</b> #1658, 27th Main, HSR Layout,Sector 2, Near NIFT College, Bengaluru, 560102, Landmark – VLCC Best NIFT NID NATA UCEED CEED Coaching in HSR Layout Bangalore</small>
                        <small><b>Contact No:</b> +91-8884544480, +91-7411523845</small>
                        <small><b>Contact Person:</b>  Mr. K. Nand Singh</small>
                        <small><b>Email:</b> live@iginteindiaedu.com</small>
                    </div>
                </div>
                <div class="testimoniall">
                    <div class="card p-3">
                    <h5>Indiranagar [Bnagalore]</h5>
                    <small><strong>Address:</strong>Metro Station, #5, Hari Prem, Best NIFT NID NATA UCEED CEED Coaching in Indiranagar, Bangalore</small>
                    <small>Indiranagar, BangaloreChinmaya Mission Hospital Rd, Indiranagar, Bengaluru, Karnataka 560038.</small>
                    <small><b>Contact No:</b> +91-9972046911</small>
                    <small><b>Contact Person:</b>  Ms. Pooja</small>
                    <small><b>Email:</b>live@iginteindiaedu.com</small>
                    </div>


                </div>
                <div class="testimoniall">
                <div class="card p-3">
                    <h5>Indiranagar [Bnagalore]</h5>
                    <small><strong>Address:</strong>Metro Station, #5, Hari Prem, Best NIFT NID NATA UCEED CEED Coaching in Indiranagar, Bangalore</small>
                    <small>Indiranagar, BangaloreChinmaya Mission Hospital Rd, Indiranagar, Bengaluru, Karnataka 560038.</small>
                    <small><b>Contact No:</b> +91-9972046911</small>
                    <small><b>Contact Person:</b>  Ms. Pooja</small>
                    <small><b>Email:</b> live@iginteindiaedu.com</small>
                    </div>
                </div>
 
                <div class="testimoniall">
                <div class="card p-3">
                    <h5>ANDHARA PRADESH</h5>
                    <h6>Hyderabad  [Main Office ]</h6>
                    <small><strong>Address:</strong> Ignite India Education Bhagya Lakshmi residence, PLOT 72 B, Jubilee Enclave, Madhapur, Hyderabad, Telangana 500081</small>
                    <small><b>Contact No:</b> +91-8884544480, +91-7411523845</small>
                    <small><b>Contact Person:</b>  Mr. Shankar / Ms Rajni</small>
                    <small><b>Email:</b> live@iginteindiaedu.com</small>
                    </div>
                </div>
            </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- include footer -->
        <?php include 'include/footer.php';?>
        <!-- include modal -->
        <?php include 'include/modal.php';?>

        <!-- include onload apply -->
        <?php include 'apply.php';?>


</body>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
<script>
    $(document).ready(function(){
  $("#carousel").owlCarousel({
      items:3,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});


$(document).ready(function(){
  $("#testimonial-slider").owlCarousel({
      items:2,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});


$(document).ready(function(){
  $("#testimoniall-slider").owlCarousel({
      items:2,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});
$(document).ready(function(){
  $("#stores-slider").owlCarousel({
      items:3,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});
$(document).ready(function(){
  $("#gallary-slider").owlCarousel({
      items:2,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});
$(document).ready(function(){
  $("#location-slider").owlCarousel({
      items:1,
      itemsDesktop:[1000,1],
      itemsDesktopSmall:[979,1],
      itemsTablet:[768,1],
      pagination:false,
      navigation:true,
      navigationText:["",""],
      autoPlay:true
  });
});
</script>