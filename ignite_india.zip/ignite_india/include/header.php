<!-- =======================================HEADER================================================== -->

<header id="header" class="d-flex align-items-center">
    
    <div class="container-fluid container-fluid-xl px-5 d-flex align-items-center justify-content-between">
        <!-- use my logo -->
    <a href="index.php" class="logo"><img src="images/ignite.png" alt="logo"></a>
        <nav class="navbar" id="navbar">
        <input type="checkbox" id="check">
                    <label for="check" class="checkbtn">
                    <i class="fa-solid fa-bars-progress"></i>
                    </label>
        <ul>
                <li><a href="index.php" class="active">HOME</a></li>
                <li><a href="#about_us">ABOUT</a></li>
                <li><a href="#our_courses">COURSES</a></li>
                <li><a href="#coaching">COACHING</a></li>
                <li><a href="#abroad">STUDY ABROAD</a></li>
                <li><a href="#contact_us">CONTACT US</a></li>
                <li><a href="tel:+9188845 44480"> <i class="fa-solid fa-phone"></i> +9188845 44480</a></li>
                 
                <div class="enquire">
            <a href="#exampleModal" type="button" class="btn-1 ml-5 text-light" data-toggle="modal"  data-toggle="tooltip">ENQUIRE US</a>
            </div>
            </ul>
           
        </nav>
    </div>
    
    <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
    <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
</header>
<div class="whatsapp">
<span  class="btn toolTip right" data-tip="Quick Contact us">+</span>
<ul>
    <li><a href="https://wa.me/+918884544480"><i class="fa-brands fa-whatsapp"></i></a></li>
    <li><a href="tel:+9188845 44480"><i class="fa-solid fa-phone"></i></a></li>
</ul>
</div>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/d3js/7.9.0/d3.min.js"></script>

<script>
$(".whatsapp").click(function(){
    $(this).toggleClass("active");
})
</script>