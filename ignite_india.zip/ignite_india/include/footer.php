<!-- =======================================footer========================================== -->

<footer class="footer py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <a href="index.php"><img src="images/ignite.png" alt=""></a>
                <h5 class="text-dark">About Us</h5>
                <p class="text-dark">Ignite India Education is inspired by the former President of India Bharat Ratna Dr. APJ Abdul Kalam’s vision of “India Beyond 2020</p>
               
            </div>
            <div class="col-md-3 col-6 links">
                <h5 class="text-dark">Quick Links</h5>
                <p><a href="index.php" class="text-dark">Home</a></p>
                <p><a href="#about_us" class="text-dark">About</a></p>
                <p><a href="#coaching" class="text-dark">Coaching</a></p>
                <p><a href="#our_courses" class="text-dark">Courses</a></p>
                <p><a href="#contact_us" class="text-dark">Contact Us</a></p>
            </div>
            <div class="col-md-2 col-6 links text-dark">
                <h5 class="text-dark">Services</h5>
                <p><a href="#our_courses" class="text-dark">NIFT</a></p>
                <p><a href="#our_courses" class="text-dark">NID</a></p>
                <p><a href="#our_courses" class="text-dark">NATA</a></p>
                <p><a href="#our_courses" class="text-dark">UCEED</a></p>
                <p><a href="#our_courses" class="text-dark">CEED</a></p>
            </div>
            <div class="col-md-3">
                <h5 class="text-dark">Contact Us</h5>
                <p><a href="tel:+9188845 44480" class="text-dark"> <i class="fa-solid fa-phone"></i> +9188845 44480</a></p>
                <p><a href="mailto:igniteindiaorg@gmail.com" class="text-dark"><i class="fa-solid fa-envelope"></i> igniteindiaorg@gmail.com</a></p>
                <div class="social_media">
                    <a href="https://www.youtube.com/igniteindiaeducation"><i class="fa-brands fa-youtube"></i></a>
                    <a href="https://www.instagram.com/ignite_india/?igshid=1tqrjuw2bjx5f"><i class="fa-brands fa-square-instagram"></i></a>
                    <a href="https://www.facebook.com/igniteindiaedu/?epa=SEARCH_BOX"><i class="fa-brands fa-square-facebook"></i></a>
                    <a href="https://twitter.com/IgniteInd?s=20"><i class="fa-brands fa-square-twitter"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="copy_right text-center pt-5  ">
        <p class="text-dark">© 2024 All Rights Reserved. Developed By <a href="https://genmish.com" class="text-dark"><b>Genmish India Private Limited</b></a></p>
    </div>
</footer>