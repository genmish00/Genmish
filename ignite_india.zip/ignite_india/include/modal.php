<?php include 'head.php';?>
<style>
    .modal .modal-header, .modal .modal-body, .modal .modal-footer {
    padding: 20px 30px;
   }
   .modal-header 
   {
    background-color:rgb(255, 170, 0);
    color:black;
   }
   .modal .modal-content {
    border-radius: 1px;
   }
   .modal .modal-footer {
    background: #ecf0f1;
    border-radius: 0 0 1px 1px;
   }
      .modal .modal-title {
          display: inline-block;
      }
   .modal .form-control {
    border-radius: 1px;
    box-shadow: none;
    border-color: #dddddd;
   }
   .modal textarea.form-control {
    resize: vertical;
   }
   .modal .btn {
    border-radius: 1px;
    min-width: 100px;
   } 
   .modal form label {
    font-weight: normal;
   }
   .modal-footer
   {
    background-color:rgb(255, 170, 0);
   }
   .modal-footer .btn{
      background:rgb(255, 33, 33);
      border: none;
      outline: none;
      color:white;
   }
   .modal-footer .btn:hover
   {
      background:rgb(255, 183, 0);
      color: black;
      transition: 0.6s;
   }
  
  .modal-title
  {
      color: 0787c3;
  }
</style>

<!-- mail send for enquiry -->
<?php 
error_reporting(0);

extract($_POST);
if (isset($send)) 
 {
			//  send to ADMIN Confirmation
			$to='mohan.genmishindia@gmail.com';
			$subject='For Enquire';
			$message='
			<html>
			<head><title>New Enquiry Details</title></head>
			<body>
			<table border=1 style="border-collapse:collapse; width:100%;">
			       
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Name</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$name.'</th></tr>
				
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Email</th><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">'.$email.'</th></tr>
			        
			        <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Phone</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$phone.'</th></tr>
              <tr><th  style="text-align: center; padding: 8px; background-color: rgb(3, 71, 128); color: white;">Course</th><th  style="text-align: center; padding: 8px; background-color:rgb(3, 71, 128); color: white;">'.$course.'</th></tr>
              
			        
			         
			</table>
			</body>
			</html>
			';

			$headers='MME-Version:  1.0'."\r\n";
			$headers='Content-Type: text/html; charset=iso-8859-1'."\r\n";
			$headers .= 'From: Ignite India . <mohan.genmishindia@gmail.com>' . "\r\n";

			mail($to, $subject, $message, $headers);
			echo"<script>alert('Message Sent Successfully')</script>";
			echo"<script>window.location.href='index.php'</script>";
}
 ?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-light"  id="exampleModalLabel">Fill Your Details</h5>
        <span></span>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form id="enquiryForm" action="" method="POST">
    <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" required>
    </div>
    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>   
    <div class="form-group">
        <label>Phone</label>
        <input type="text" name="phone" class="form-control phone" required>
        <small class="error-message" style="color: red;"></small>
    </div>
    <div class="form-group">
        <label>Course</label>
        <input type="text" class="form-control" name="course" required>
    </div>
    <div class="modal-footer">
        <button type="submit" name="send" class="btn btn-primary">ENQUIRE</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    </div>
</form>
      </div>
    </div>
  </div>
</div>

<!-- Script to open modal on page load -->
<script>
  $(document).ready(function(){
    $('#exampleModal').modal('show');
  });


document.getElementById("enquiryForm").addEventListener("submit", function(event) {
        var phoneInput = document.querySelector(".phone");
        var phone = phoneInput.value.trim();

        // Regular expression for Indian mobile numbers
        var phoneRegex = /^[6-9]\d{9}$/;

        if (!phoneRegex.test(phone)) {
            var errorMessage = document.querySelector(".error-message");
            errorMessage.textContent = "Please enter a valid Indian mobile number.";
            event.preventDefault(); // Prevent form submission
        }
    });
</script
</script>





